SCML OneShot
============
    This module describes the Supply Chain Management League Platform as run
    starting 2021 in the one-shot track of ANAC


.. automodapi:: scml.oneshot
    :members:
    :show-inheritance:

.. automodapi:: scml.oneshot.rl
    :members:
    :show-inheritance:
