SCML Standard
=============
    This module describes the Supply Chain Management League Platform as run
    starting 2024 in the standard track of ANAC


.. automodapi:: scml.std
    :members:
    :show-inheritance:
